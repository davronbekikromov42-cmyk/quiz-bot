# Fayl formati (txt, docx, xlsx) uchun:
#
# Savol matni
# A) variant
# B) variant
# C) variant
# D) variant
# Javob: A
#
# Savollar orasida bo'sh qator bo'lishi kerak

def parse_txt(text):
    questions = []
    blocks = text.strip().split("\n\n")
    for block in blocks:
        lines = [l.strip() for l in block.strip().splitlines() if l.strip()]
        if len(lines) < 6:
            continue
        try:
            q_text = lines[0]
            a = lines[1].lstrip("Aa)").strip()
            b = lines[2].lstrip("Bb)").strip()
            c = lines[3].lstrip("Cc)").strip()
            d = lines[4].lstrip("Dd)").strip()
            correct = lines[5].replace("Javob:", "").replace("javob:", "").strip().upper()
            if correct in ["A", "B", "C", "D"]:
                questions.append({
                    "text": q_text,
                    "A": a, "B": b, "C": c, "D": d,
                    "correct": correct
                })
        except:
            continue
    return questions

def parse_docx(file_path):
    from docx import Document
    doc = Document(file_path)
    full_text = "\n".join([p.text for p in doc.paragraphs])
    return parse_txt(full_text)

def parse_xlsx(file_path):
    from openpyxl import load_workbook
    wb = load_workbook(file_path)
    ws = wb.active
    questions = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if len(row) >= 6 and row[0]:
            correct = str(row[5]).strip().upper() if row[5] else ""
            if correct in ["A", "B", "C", "D"]:
                questions.append({
                    "text": str(row[0]),
                    "A": str(row[1]),
                    "B": str(row[2]),
                    "C": str(row[3]),
                    "D": str(row[4]),
                    "correct": correct
                })
    return questions
