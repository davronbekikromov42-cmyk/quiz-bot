from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters, ConversationHandler
)
from database import *
from file_parser import parse_txt, parse_docx, parse_xlsx

TOKEN = "TOKENINGIZNI_QO'YING"

TITLE, Q_TEXT, Q_A, Q_B, Q_C, Q_D, Q_ANS, Q_MORE = range(8)

# ── START ──
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    save_user(user.id, user.full_name)
    kb = [
        [InlineKeyboardButton("📄 Fayl yuborish", callback_data="upload")],
        [InlineKeyboardButton("✍️ Qo'lda test tuzish", callback_data="create")],
        [InlineKeyboardButton("🎯 Test yechish", callback_data="solve")],
        [InlineKeyboardButton("📊 Natijalarim", callback_data="myresults")],
        [InlineKeyboardButton("🏆 Reyting", callback_data="ranking")],
    ]
    await update.message.reply_text(
        f"Salom, {user.first_name}! 🤖\n\n*Quiz Bot*ga xush kelibsiz!",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )

# ── FAYL YUBORISH ──
async def upload_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.message.reply_text(
        "📎 Fayl yuboring (txt, docx yoki xlsx)\n\n"
        "*Fayl formati:*\n"
        "```\n"
        "Savol matni\n"
        "A) birinchi variant\n"
        "B) ikkinchi variant\n"
        "C) uchinchi variant\n"
        "D) to'rtinchi variant\n"
        "Javob: A\n"
        "```\n"
        "Savollar orasida bo'sh qator qoldiring",
        parse_mode="Markdown"
    )

async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    if not doc:
        return
    fname = doc.file_name.lower()
    file = await doc.get_file()
    path = f"/tmp/{doc.file_name}"
    await file.download_to_drive(path)

    try:
        if fname.endswith(".txt"):
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            questions = parse_txt(text)
        elif fname.endswith(".docx"):
            questions = parse_docx(path)
        elif fname.endswith(".xlsx"):
            questions = parse_xlsx(path)
        else:
            await update.message.reply_text("❌ Faqat txt, docx yoki xlsx fayl yuboring!")
            return ConversationHandler.END

        if not questions:
            await update.message.reply_text(
                "❌ Fayldan savollar topilmadi!\nFormat to'g'riligini tekshiring."
            )
            return ConversationHandler.END

        context.user_data["file_questions"] = questions
        context.user_data["mode"] = "file"
        await update.message.reply_text(
            f"✅ *{len(questions)} ta savol* topildi!\n\nTest nomini kiriting:",
            parse_mode="Markdown"
        )
        return TITLE

    except Exception as e:
        await update.message.reply_text(f"❌ Xato: {str(e)}")
        return ConversationHandler.END

# ── TEST TUZISH (QO'LDA) ──
async def create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    context.user_data["mode"] = "manual"
    await update.callback_query.message.reply_text("📚 Test nomini kiriting:")
    return TITLE

async def get_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    title = update.message.text
    creator_id = update.effective_user.id

    if context.user_data.get("mode") == "file":
        quiz_id = create_quiz(creator_id, title)
        questions = context.user_data.get("file_questions", [])
        for q in questions:
            add_question(quiz_id, q["text"], q["A"], q["B"], q["C"], q["D"], q["correct"])
        await update.message.reply_text(
            f"🎉 *{title}* saqlandi! {len(questions)} ta savol.\n\n/start — menyu",
            parse_mode="Markdown"
        )
        return ConversationHandler.END

    qid = create_quiz(creator_id, title)
    context.user_data["qid"] = qid
    context.user_data["title"] = title
    await update.message.reply_text("✏️ 1-savol matnini kiriting:")
    return Q_TEXT

async def q_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["cur_q"] = {"text": update.message.text}
    await update.message.reply_text("A) variantni kiriting:")
    return Q_A

async def q_a(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["cur_q"]["A"] = update.message.text
    await update.message.reply_text("B) variantni kiriting:")
    return Q_B

async def q_b(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["cur_q"]["B"] = update.message.text
    await update.message.reply_text("C) variantni kiriting:")
    return Q_C

async def q_c(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["cur_q"]["C"] = update.message.text
    await update.message.reply_text("D) variantni kiriting:")
    return Q_D

async def q_d(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["cur_q"]["D"] = update.message.text
    kb = [[
        InlineKeyboardButton("A", callback_data="ca_A"),
        InlineKeyboardButton("B", callback_data="ca_B"),
        InlineKeyboardButton("C", callback_data="ca_C"),
        InlineKeyboardButton("D", callback_data="ca_D"),
    ]]
    await update.message.reply_text("✅ To'g'ri javobni tanlang:", reply_markup=InlineKeyboardMarkup(kb))
    return Q_ANS

async def q_ans(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    correct = update.callback_query.data.split("_")[1]
    q = context.user_data["cur_q"]
    q["correct"] = correct
    add_question(context.user_data["qid"], q["text"], q["A"], q["B"], q["C"], q["D"], correct)
    n = len(get_questions(context.user_data["qid"]))
    kb = [
        [InlineKeyboardButton("➕ Yana savol", callback_data="more_yes")],
        [InlineKeyboardButton("✅ Tugatish", callback_data="more_no")],
    ]
    await update.callback_query.message.reply_text(
        f"✅ {n}-savol saqlandi!", reply_markup=InlineKeyboardMarkup(kb)
    )
    return Q_MORE

async def q_more(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    if update.callback_query.data == "more_yes":
        n = len(get_questions(context.user_data["qid"])) + 1
        await update.callback_query.message.reply_text(f"✏️ {n}-savol matnini kiriting:")
        return Q_TEXT
    else:
        n = len(get_questions(context.user_data["qid"]))
        await update.callback_query.message.reply_text(
            f"🎉 Test tayyor! {n} ta savol saqlandi.\n\n/start — menyu",
            parse_mode="Markdown"
        )
        return ConversationHandler.END

# ── TEST YECHISH ──
async def solve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    quizzes = get_quizzes()
    if not quizzes:
        await update.callback_query.message.reply_text("❌ Hozircha testlar yo'q!")
        return
    kb = [
        [InlineKeyboardButton(f"📋 {q[1]}", callback_data=f"sq_{q[0]}")]
        for q in quizzes
    ]
    await update.callback_query.message.reply_text(
        "🎯 Testni tanlang:", reply_markup=InlineKeyboardMarkup(kb)
    )

async def start_solve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    qid = int(update.callback_query.data.split("_")[1])
    questions = get_questions(qid)
    if not questions:
        await update.callback_query.message.reply_text("❌ Bu testda savollar yo'q!")
        return
    context.user_data["sq_id"] = qid
    context.user_data["sq_questions"] = questions
    context.user_data["sq_idx"] = 0
    context.user_data["sq_score"] = 0
    await ask_question(update.callback_query.message, context)

async def ask_question(message, context):
    questions = context.user_data["sq_questions"]
    idx = context.user_data["sq_idx"]
    q = questions[idx]
    total = len(questions)
    text = (
        f"❓ *{idx+1}/{total}-savol:*\n\n{q[2]}\n\n"
        f"🅐 {q[3]}\n🅑 {q[4]}\n🅒 {q[5]}\n🅓 {q[6]}"
    )
    kb = [[
        InlineKeyboardButton("A", callback_data="sa_A"),
        InlineKeyboardButton("B", callback_data="sa_B"),
        InlineKeyboardButton("C", callback_data="sa_C"),
        InlineKeyboardButton("D", callback_data="sa_D"),
    ]]
    await message.reply_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

async def answer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    chosen = update.callback_query.data.split("_")[1]
    questions = context.user_data["sq_questions"]
    idx = context.user_data["sq_idx"]
    q = questions[idx]
    correct = q[7]

    if chosen == correct:
        context.user_data["sq_score"] += 1
        await update.callback_query.message.reply_text("✅ To'g'ri!")
    else:
        await update.callback_query.message.reply_text(
            f"❌ Noto'g'ri! To'g'ri javob: *{correct}*", parse_mode="Markdown"
        )

    context.user_data["sq_idx"] += 1
    total = len(questions)

    if context.user_data["sq_idx"] < total:
        await ask_question(update.callback_query.message, context)
    else:
        score = context.user_data["sq_score"]
        percent = round(score / total * 100)
        save_result(update.effective_user.id, context.user_data["sq_id"], score, total)
        await update.callback_query.message.reply_text(
            f"🏁 *Test yakunlandi!*\n\n✅ {score}/{total} — {percent}%\n\n/start — menyu",
            parse_mode="Markdown"
        )

# ── NATIJALAR ──
async def my_results(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    results = get_my_results(update.effective_user.id)
    if not results:
        await update.callback_query.message.reply_text("📊 Siz hali test yechmagansiz!")
        return
    text = "📊 *Sizning natijalaringiz:*\n\n"
    for r in results:
        percent = round(r[1] / r[2] * 100)
        text += f"📋 {r[0]}\n✅ {r[1]}/{r[2]} — {percent}%\n📅 {r[3][:10]}\n\n"
    await update.callback_query.message.reply_text(text, parse_mode="Markdown")

# ── REYTING ──
async def ranking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    quizzes = get_quizzes()
    if not quizzes:
        await update.callback_query.message.reply_text("❌ Testlar yo'q!")
        return
    kb = [
        [InlineKeyboardButton(f"🏆 {q[1]}", callback_data=f"rank_{q[0]}")]
        for q in quizzes
    ]
    await update.callback_query.message.reply_text(
        "Qaysi test reytingini ko'rmoqchisiz?",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def show_ranking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    qid = int(update.callback_query.data.split("_")[1])
    rows = get_ranking(qid)
    if not rows:
        await update.callback_query.message.reply_text("Hali natijalar yo'q!")
        return
    text = "🏆 *Reyting:*\n\n"
    medals = ["🥇", "🥈", "🥉"]
    for i, r in enumerate(rows):
        percent = round(r[1] / r[2] * 100)
        medal = medals[i] if i < 3 else f"{i+1}."
        text += f"{medal} {r[0]} — {r[1]}/{r[2]} ({percent}%)\n"
    await update.callback_query.message.reply_text(text, parse_mode="Markdown")

# ── MAIN ──
init_db()

file_conv = ConversationHandler(
    entry_points=[MessageHandler(filters.Document.ALL, handle_file)],
    states={
        TITLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_title)],
    },
    fallbacks=[CommandHandler("start", start)]
)

manual_conv = ConversationHandler(
    entry_points=[CallbackQueryHandler(create, pattern="^create$")],
    states={
        TITLE:  [MessageHandler(filters.TEXT & ~filters.COMMAND, get_title)],
        Q_TEXT: [MessageHandler(filters.TEXT & ~filters.COMMAND, q_text)],
        Q_A:    [MessageHandler(filters.TEXT & ~filters.COMMAND, q_a)],
        Q_B:    [MessageHandler(filters.TEXT & ~filters.COMMAND, q_b)],
        Q_C:    [MessageHandler(filters.TEXT & ~filters.COMMAND, q_c)],
        Q_D:    [MessageHandler(filters.TEXT & ~filters.COMMAND, q_d)],
        Q_ANS:  [CallbackQueryHandler(q_ans, pattern="^ca_")],
        Q_MORE: [CallbackQueryHandler(q_more, pattern="^more_")],
    },
    fallbacks=[CommandHandler("start", start)]
)

application = ApplicationBuilder().token(TOKEN).connect_timeout(30).read_timeout(30).write_timeout(30).build()
application.add_handler(CommandHandler("start", start))
application.add_handler(file_conv)
application.add_handler(manual_conv)
application.add_handler(CallbackQueryHandler(upload_prompt, pattern="^upload$"))
application.add_handler(CallbackQueryHandler(solve, pattern="^solve$"))
application.add_handler(CallbackQueryHandler(start_solve, pattern="^sq_"))
application.add_handler(CallbackQueryHandler(answer, pattern="^sa_"))
application.add_handler(CallbackQueryHandler(my_results, pattern="^myresults$"))
application.add_handler(CallbackQueryHandler(ranking, pattern="^ranking$"))
application.add_handler(CallbackQueryHandler(show_ranking, pattern="^rank_"))

print("✅ Bot ishga tushdi!")
application.run_polling()
