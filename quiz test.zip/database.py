import sqlite3

DB = "quiz.db"

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        user_id INTEGER UNIQUE,
        name TEXT,
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS quizzes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        creator_id INTEGER,
        title TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quiz_id INTEGER,
        question_text TEXT,
        option_a TEXT,
        option_b TEXT,
        option_c TEXT,
        option_d TEXT,
        correct TEXT,
        FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        quiz_id INTEGER,
        score INTEGER,
        total INTEGER,
        taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.commit()
    conn.close()

def save_user(user_id, name):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (user_id, name) VALUES (?, ?)", (user_id, name))
    conn.commit()
    conn.close()

def create_quiz(creator_id, title):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO quizzes (creator_id, title) VALUES (?, ?)", (creator_id, title))
    qid = c.lastrowid
    conn.commit()
    conn.close()
    return qid

def add_question(quiz_id, text, a, b, c_, d, correct):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""INSERT INTO questions 
        (quiz_id, question_text, option_a, option_b, option_c, option_d, correct)
        VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (quiz_id, text, a, b, c_, d, correct))
    conn.commit()
    conn.close()

def get_quizzes():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT id, title, creator_id FROM quizzes")
    rows = c.fetchall()
    conn.close()
    return rows

def get_questions(quiz_id):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM questions WHERE quiz_id=?", (quiz_id,))
    rows = c.fetchall()
    conn.close()
    return rows

def save_result(user_id, quiz_id, score, total):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("INSERT INTO results (user_id, quiz_id, score, total) VALUES (?, ?, ?, ?)",
              (user_id, quiz_id, score, total))
    conn.commit()
    conn.close()

def get_my_results(user_id):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""SELECT q.title, r.score, r.total, r.taken_at
        FROM results r JOIN quizzes q ON r.quiz_id = q.id
        WHERE r.user_id = ? ORDER BY r.taken_at DESC""", (user_id,))
    rows = c.fetchall()
    conn.close()
    return rows

def get_ranking(quiz_id):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""SELECT u.name, r.score, r.total
        FROM results r JOIN users u ON r.user_id = u.user_id
        WHERE r.quiz_id = ?
        ORDER BY r.score DESC LIMIT 10""", (quiz_id,))
    rows = c.fetchall()
    conn.close()
    return rows
